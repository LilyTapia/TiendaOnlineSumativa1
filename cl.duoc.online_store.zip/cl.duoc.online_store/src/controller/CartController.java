package controller;

import java.util.List;
import model.Product;
import view.CartView;

public class CartController {

    private List<Product> cart;
    private CartView view;

    public CartController(List<Product> cart, CartView view) {
        this.cart = cart;
        this.view = view;
    }

    public void updateView() {
        view.displayCart(cart);
    }

    public void addProduct(Product product) {
        cart.add(product);
        updateView();
    }

    public void removeProduct(Product product) {
        cart.remove(product);
        updateView();
    }

}
