package controller;

import controller.Command;
import model.Component;
import model.PromotionDecorator;

public class PromotionCommand implements Command {

    private Component product;
    private double promotionAmount;

    public PromotionCommand(Component product, double promotionAmount) {
        this.product = product;
        this.promotionAmount = promotionAmount;
    }

    @Override
    public void ejecutar() {
        Component promotionalProduct = new PromotionDecorator(product, promotionAmount);
        System.out.println("Producto con promoción aplicada: " + promotionalProduct);
    }
}