package controller;

import model.Product;
import view.ProductView;

public class ProductController {

    private Product model;
    private ProductView view;

    public ProductController(Product model, ProductView view) {
        this.model = model;
        this.view = view;
    }

    public void updateView() {
        view.displayProductDetails(model);
    }

}
