package controller;


public interface Command {
    void ejecutar (); // método que encapsula la lógica al momento de aplicar descuentos 
    
}