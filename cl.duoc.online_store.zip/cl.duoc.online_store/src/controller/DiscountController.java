package controller;

import model.DiscountManager;
import model.Product;
import view.DiscountView;

public class DiscountController {

    private DiscountManager discountManager;
    private DiscountView view;

    public DiscountController(DiscountManager discountManager, DiscountView view) {
        this.discountManager = discountManager;
        this.view = view;
    }

    public void applyDiscount(double discountPercentage) {
        discountManager.getInstance((Product) discountManager.component).applyDiscount(discountPercentage);
        view.displayDiscount((Product) discountManager.component);
    }
}
