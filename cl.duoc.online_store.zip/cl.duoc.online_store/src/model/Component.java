
package model;


public interface Component {
    double getPrice(); // metodo para obtener el precio del componente
    String getName (); // metodo para obtener el nombre del componente 
}