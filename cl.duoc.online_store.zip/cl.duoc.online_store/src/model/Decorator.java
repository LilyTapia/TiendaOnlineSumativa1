package model;

import model.Component;

public abstract class Decorator implements Component {

    public Component component;

    public Decorator(Component component) {
        this.component = component;
    }

    @Override
    public double getPrice() {
        return component.getPrice();
    }

    @Override
    public String getName() {
        return component.getName();
    }

}