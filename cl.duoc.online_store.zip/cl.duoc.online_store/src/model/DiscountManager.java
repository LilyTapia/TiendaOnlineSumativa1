package model;

import model.Product;

public class DiscountManager extends Decorator {

    private static DiscountManager instance;

    private DiscountManager(Product product) {
        super(product);
    }

    public static DiscountManager getInstance(Product product) {
        if (instance == null) {
            instance = new DiscountManager(product);
        } else {
            instance.component = product;
        }
        return instance;
    }

    @Override
    public double getPrice() {
        return component.getPrice();
    }

    @Override
    public String toString() {
        return component.getName() + " con gestión de descuento aplicada - $" + getPrice();
    }

    public void applyDiscount(double discountPercentage) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}