package view;

import java.util.List;
import model.Product;

public class CartView {

    public void displayCart(List<Product> products) {
        System.out.println("Carrito de compras:");
        for (Product product : products){
            System.out.println("- " +  product);
        }
    }
}
