
package view;

import model.Product;

public class ProductView {
    public void displayProductDetails (Product product){
        System.out.println("Producto: " + product.getName() + "Precio:$"+ product.getPrice());
    }
}
