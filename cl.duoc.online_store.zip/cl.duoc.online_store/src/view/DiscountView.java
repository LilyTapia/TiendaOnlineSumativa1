
package view;

import model.Product;

public class DiscountView {
    public void displayDiscount (Product product){
        System.out.println("Descuento aplicado al producto: "+ product.getName()+ "- Nuevo precio :$" + product.getPrice());
    }
    
}
